package StepDefinitions;


import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import demoqa.PageObjects.Logconfigurator;
import demoqa.PageObjects.LoginPageObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import demoqa.LaunchBrowser;
import demoqa.ReadProperty;


public class CheckLoginFeature{
	LaunchBrowser LB = new LaunchBrowser();
	WebDriver driver = LB.getDriver();
	LoginPageObject LP = PageFactory.initElements(driver, LoginPageObject.class);
	Properties prop = ReadProperty.ReadPropertyFile();

	@Given("^Open the browser url$")
	public void open_the_browser_url() throws Throwable { 
		System.out.println("given open browser is starting");	
		String URL=prop.getProperty("loginurl");
		driver.navigate().to(URL);
		Logconfigurator.info("launched URL successfully");
	}

	@Given("^Enter the username and password$")
	public void enter_the_username_and_password() throws Throwable {
		String username = prop.getProperty("UserName");
		String password = prop.getProperty("Password");
		LP.Password.sendKeys(password);
		LP.UserName.sendKeys(username);
		Logconfigurator.info("entered username and password successfully"); 

	}

	@When("^Click the Sign-In button$")
	public void click_the_Sign_In_button() throws Throwable {
		LP.submit.click();
		Logconfigurator.info("submitted successfully"); 
	}

	@Then("^Verify the dashboard login url$")
	public void verify_the_dashboard_login_url() throws Throwable {
		String url = driver.getCurrentUrl();
		String dashboard = prop.getProperty("Dashboard_Page");
		if(url.equalsIgnoreCase(dashboard)) {
			Logconfigurator.info("landing page url is validated successfully"); 
		}else {
			Logconfigurator.info("incorrect landing page"); 
		}
	}
}

