package Resources.Runner;




import org.junit.runner.RunWith;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import demoqa.LaunchBrowser;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" }, features = "src/test/java/Resources/Features",
		/* features = {"@rerun/target/rerun.txt"}, */
		glue = "StepDefinitions") 



public class CucumberRunner {

@BeforeClass
public void setup() throws Exception {
LaunchBrowser lb = new LaunchBrowser();
lb.setBrowser();

}

}


