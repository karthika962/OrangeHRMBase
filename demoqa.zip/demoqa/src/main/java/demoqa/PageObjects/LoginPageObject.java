package demoqa.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPageObject{
WebDriver driver;
	public LoginPageObject(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//WebElement username1 = driver.findElement(By.id("txtUsername"));
	//username1.sendKeys("123");

	
	
	@FindBy(id = "txtUsername")
	public WebElement UserName;


	@FindBy(id = "txtPassword")
	public WebElement Password;

	@FindBy(id = "btnLogin")
	public WebElement submit;

	@FindBy(xpath = "//*[@href]")
	public List<WebElement> landingPageLink;

}
