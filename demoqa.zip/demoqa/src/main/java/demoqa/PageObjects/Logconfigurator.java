package demoqa.PageObjects;


import org.apache.log4j.Logger;  


public class Logconfigurator {



	static Logger Logger1 = Logger.getLogger(Logconfigurator.class);//

	// This is to print log for the beginning of the test case, as we usually run so many test cases as a test suite




	public static void startTestCase(String sTestCaseName){

		Logger1.info("****************************************************************************************");

		Logger1.info("****************************************************************************************");

		Logger1.info("$$$$$$$$$$$$$$$$$$$$$                 "+sTestCaseName+ "       $$$$$$$$$$$$$$$$$$$$$$$$$");

		Logger1.info("****************************************************************************************");

		Logger1.info("****************************************************************************************");

	}


	//This is to print log for the ending of the test case

	public static void endTestCase(String sTestCaseName){

		Logger1.info("XXXXXXXXXXXXXXXXXXXXXXX             "+"-E---N---D-"+"             XXXXXXXXXXXXXXXXXXXXXX");

		Logger1.info("X");

		Logger1.info("X");

		Logger1.info("X");

		Logger1.info("X");

	}

	// Need to create these methods, so that they can be called  

	public static void info(String message) {

		Logger1.info(message);

	}

	public static void warn(String message) {

		Logger1.warn(message);

	}

	public static void error(String message) {

		Logger1.error(message);

	}

	public static void fatal(String message) {

		Logger1.fatal(message);

	}

	public static void debug(String message) {

		Logger1.debug(message);

	}

}
