package demoqa;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import demoqa.PageObjects.*;


import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class LaunchBrowser extends Logconfigurator {
	public static WebDriver driver = null;
	ReadProperty property = new ReadProperty();
	
	Properties prop = ReadProperty.ReadPropertyFile();
	
	public LaunchBrowser() {
		try {
			setBrowser();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setBrowser() throws Exception {
		// TODO Auto-generated method stub
		DOMConfigurator.configure("log4j.xml");
		String myBrowser = prop.getProperty("browser");
		System.out.println(myBrowser);
		myBrowser = myBrowser.trim();

		
		if("chrome".equalsIgnoreCase(myBrowser)){
			Logconfigurator.info("launching chrome");
			System.setProperty("webdriver.chrome.driver", "D:\\Selenium drivers\\chromedriver.exe");
		
			ChromeOptions options = new ChromeOptions();
			//options.addArguments("--disable-notifications");
			//options.addArguments("--start-maximized");
			driver = new ChromeDriver();
			//((RemoteWebDriver) driver).setLogLevel(Level.INFO);			
		}else if("firefox".equalsIgnoreCase(myBrowser)){
			System.out.println("launching firefox");
			System.setProperty("webdriver.gecko.driver", "D:\\Selenium drivers\\geckodriver.exe");

			driver = new FirefoxDriver();
			driver.manage().window().maximize();
		}else if("edge".equalsIgnoreCase(myBrowser)){
			try {
				driver = new EdgeDriver();
				Thread.sleep(10000);
			} catch (InterruptedException we) {
				Logconfigurator.error(we.getMessage());
			}
		}else if("ie".equalsIgnoreCase(myBrowser)){
			System.setProperty("webdriver.ie.driver", "drivers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			driver.manage().window().maximize();
		}
			else{
				System.out.println("exception thrown");
			throw new Exception();
		}
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(90000, TimeUnit.SECONDS);

	}
	public WebDriver getDriver() {
		return driver;
	}
	
	public void quitBrowser() {
		driver.quit();
	}

	
}


