package demoqa;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import demoqa.PageObjects.Logconfigurator;

public class ReadProperty extends Logconfigurator{
	

	public static Properties prop = new Properties();
	public static 	FileInputStream fileInput = null;

	public ReadProperty() {
		ReadPropertyFile();
	}
	
	public static Properties ReadPropertyFile() {
		try {
			File file = new File("C:\\Users\\KArjunan3\\Documents\\demoqa-workspace\\demoqa\\utilities\\config.properties");
			FileInputStream fileInput = new FileInputStream(file);
			prop.load(fileInput);
		
		}catch(Exception e) {
			Logconfigurator.info("Exception thrown while reading property file" +e);
		
		}
		return (prop);

	}

}


